#!/bin/bash
if [ ! -n "$1" ];then
    echo "";
    echo "---------------------------------------------------------";
    echo "This script will perform equilibration of the solvated system, followed by production run";
    echo "Example: $0 0";
    echo "This will perform gpu based calculations at 0th gpu card";
    echo "---------------------------------------------------------";
    echo "";
    exit
fi
echo ******************************************************;
echo Selected CUDA_VISIBLE_DEVICES for the current MD = $1;
echo ******************************************************;

export CUDA_VISIBLE_DEVICES=$1

pmemd.cuda -O -i equil.in -o equil.out -p com-sol1.prmtop -c density.rst -r equil.rst -x equil.nc -ref density.rst
pmemd.cuda -O -i equil1.in -o equil1.out -p com-sol1.prmtop -c equil.rst -r equil1.rst -x equil1.nc -ref equil.rst
pmemd.cuda -O -i prod.in -o prod1.out -p com-sol1.prmtop -c equil1.rst -r prod1.rst -x prod1.nc -ref equil1.rst
