#!/bin/bash
if [ ! -n "$1" ];then
    echo ""
    echo "This script will help extracting a particular frame from the trajectory"
    echo "Use the following flags to run the script"
	echo "-n = Name of the trajectory with file extension (.nc or .mdcrd)"
	echo "-f = Frame no. to extract"
    echo ""
    echo "Usage: $0 -n <trajname> -tp <timeperiod>"
    echo ""
    echo "Example: $0 -n prod1.nc -tp 20"
    echo "This will extract 10000th frame from the trajectory"
    echo ""
    exit
fi

while getopts n:f: flag
do
	case "${flag}" in
		n) traj=${OPTARG};;
		tp) timeperiod=${OPTARG};;
	esac
done

# Frame calculation
x=500;
y=$timeperiod;
frame=$((x *y));

echo "***********************************************************";
echo "Name of the Trajectory: $traj";
echo "Frame No.: $timeperiod";
echo "Frame No.: $frame";
echo "***********************************************************";

# Removing exisiting files to avoid duplication
rm extframe.in;

# Extraction of particular frame from the input Trajectory
echo "trajin $traj $frame $frame 1" >> extframe.in;
echo "reference com-sol1.inpcrd" >> extframe.in;
echo "strip :Na+" >> extframe.in;
echo "strip :Cl-" >> extframe.in;
echo "strip :WAT" >> extframe.in;
echo "trajout frame_$timeperiod.pdb" >> extframe.in;

cpptraj -p com-sol1.prmtop -i extframe.in;

echo "***********************************************************";
echo "Extraction of frame at $timeperiod ns is done successfully!";
echo "***********************************************************";